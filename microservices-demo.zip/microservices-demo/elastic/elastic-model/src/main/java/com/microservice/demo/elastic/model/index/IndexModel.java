package com.microservice.demo.elastic.model.index;

public interface IndexModel {
    String getId();
}
