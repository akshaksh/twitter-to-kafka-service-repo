package com.microservices.demo.index.client.service.impl;

import com.microservice.demo.elastic.model.index.impl.TwitterIndexModel;
import com.microservices.demo.config.ElasticConfigData;
import com.microservices.demo.index.client.service.ElasticIndexClient;
import com.microservices.demo.index.client.util.ElasticIndexUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@ConditionalOnProperty(name = "elastic-config.is-repository", havingValue = "true")
public class TwitterElasticIndexClient implements ElasticIndexClient {

  private static final Logger LOG = LoggerFactory.getLogger(TwitterElasticIndexClient.class);

  private final ElasticConfigData elasticConfigData;

  private final ElasticsearchOperations elasticsearchOperations;

  private final ElasticIndexUtil<TwitterIndexModel> elasticIndexUtil;

  public TwitterElasticIndexClient(ElasticConfigData elasticConfigData,
      ElasticsearchOperations elasticsearchOperations,
      ElasticIndexUtil<TwitterIndexModel> elasticIndexUtil) {
    this.elasticConfigData = elasticConfigData;
    this.elasticsearchOperations = elasticsearchOperations;
    this.elasticIndexUtil = elasticIndexUtil;
  }

  @Override
  public List<String> save(List documents) {
    List<IndexQuery> indexQueries = elasticIndexUtil.getIndexQueries(documents);
    List<String> documentIds = elasticsearchOperations
        .bulkIndex(indexQueries, IndexCoordinates.of(elasticConfigData.getIndexName())).stream()
        .map(item -> item.getId()).collect(Collectors.toList());
    LOG.info("Documents indexed successfully with type: {}, and ids: {}",
        TwitterIndexModel.class.getName(), documentIds);
    return documentIds;
  }
}
